<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?php if (isset($page_title)) echo $page_title; ?></h1>
</div>

<div class="row">
    <div class="col-md-12 col-lg-12">
        <img class="img-fluid" src="<?= base_url() ?>template/img/large-white.jpeg">
    </div>
</div>