<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?php if (isset($page_title)) echo $page_title; ?></h1>
</div>

<div class="row">
    <div class="col-md-12">

        <a href="<?= site_url('admin/master/operasional/add'); ?>" class="btn btn-primary btn-sm mb-2">
            Tambah Operasional
        </a>
        <a href="<?= site_url('admin/master/operasional/koreksi'); ?>" class="btn btn-danger btn-sm mb-2">
            Koreksi Operasional
        </a>
        <?php
        if ($this->session->flashdata('info')) {
            echo "<br/>";
            echo $this->session->flashdata('info');
        }
        #echo $this->db->last_query();
        ?>

        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary"><?php if (isset($card_name)) echo $card_name; ?></h6>
            </div>
            <!-- Card Body -->
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="example" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Tgl.</th>
                                <th>Nama Rek.</th>
                                <th>Keterangan</th>
                                <th>Nominal</th>
                                <!--<th><i class="fas fa-cog"></i></th>-->
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>No.</th>
                                <th>Tgl.</th>
                                <th>Nama Rek.</th>
                                <th>Keterangan</th>
                                <th>Nominal</th>
                                <!--<th><i class="fas fa-cog"></i></th>-->
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $no = 1;
                            foreach ($daftar as $row) : ?>
                                <tr>
                                    <td><?= $no ?></td>
                                    <td><?= date('d/m/Y', strtotime($row['TGL'])) ?></td>
                                    <td><?= $row['POS_NAME'] ?></td>
                                    <td><?= $row['KETERANGAN'] ?></td>
                                    <td><?= number_format($row['KREDIT'], 0, ',', '.') ?></td>
                                    <!--<td>
                                        <a title="Edit" href="<?= site_url('admin/master/operasional/edit/') . $row['ID'] ?>" class='btn btn-sm btn-warning'><i class="fas fa-edit"></i></a>
                                    </td>-->
                                </tr>
                            <?php $no++;
                            endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>