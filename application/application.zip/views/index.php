<?php $this->load->view('_layouts/head'); ?>
<?php $this->load->view('_layouts/wrapper'); ?>
<?php $this->load->view('_layouts/footer'); ?>