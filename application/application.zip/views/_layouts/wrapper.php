<div id="wrapper">
    <?php $this->load->view('_layouts/sidebar'); ?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
        <?php $this->load->view('_layouts/main/content'); ?>
    </div>
</div>